import { createContext, useContext, useState, ReactNode } from 'react';

type Lang = 'en' | 'kn';

const translations = {
  en: {
    // Navbar
    nav: {
      home: 'Home',
      about: 'About',
      campus: 'Campus',
      activities: 'Activities',
      donors: 'Donors',
      contact: 'Contact',
      donateNow: 'Donate Now',
      langToggle: 'ಕನ್ನಡ',
    },
    // Hero
    hero: {
      title: 'Free Education for Every Child',
      subtitle: 'Pramila Veerappa Educational Trust · Est. 1985 · Valagerehalli, Maddur, Karnataka',
      donate: 'Donate Now',
      story: 'Our Story →',
    },
    // Stats
    stats: {
      totalStudents: 'Total Students',
      teachers: 'Teachers',
      estYear: 'Est. Year',
      campusArea: 'Campus Area',
      taxBenefit: 'Tax Benefit',
    },
    // About
    about: {
      label: 'Our Story',
      title: 'A Vision Born in a Village',
      p1: 'V.K. Veerappa (1929–2017) was born into a poor family in the small village of Valagerehalli. He worked hard, became an Engineer, but never forgot his roots.',
      p2: 'In 1985, he started the school in a small shed with a few children. Through unwavering determination, he collected charitable funds and built the entire campus over two decades.',
      p3: 'Today, over 200 students study here and have gone on to become engineers, doctors, and business people — fulfilling his dream.',
      quote: '"Progress in every country depends mainly on the education of its people." — Sir M. Visvesvaraya',
    },
    // Campus
    campus: {
      label: 'Our Campus',
      subtitle: '4 Buildings · 5 Acres · Valagerehalli',
      mapCaption: 'Campus layout — Valagerehalli, Maddur',
      boys: 'Boys',
      girls: 'Girls',
      teachersStat: 'Teachers',
      head: 'Head',
    },
    // Activities
    activities: {
      label: 'Activities & Events',
      subtitle: 'A glimpse into student life',
      all: 'All',
      cultural: 'Cultural',
      academic: 'Academic',
      sports: 'Sports',
      infrastructure: 'Infrastructure',
      viewPhotos: 'View Photos →',
    },
    // Donors
    donors: {
      label: 'Our Donors',
      subtitle: 'We are grateful to those who believed in this dream',
      manyDonors: '...and many individual donors. Thank you.',
    },
    // Contact
    contact: {
      label: 'Support Us',
      quote: '"Tiny drops of water make a mighty ocean."',
      subtitle: 'Every little contribution matters. Help us improve our school\'s infrastructure and education.',
      getInTouch: 'Get in Touch',
      visitUs: 'Visit Us',
      directions: '90km from Bengaluru via NH 275',
      supportMission: 'Support Our Mission',
      registered: 'Registered under 12A & 80G',
      donateNow: 'Donate Now',
    },
    // Footer
    footer: {
      trustName: 'Pramila Veerappa Educational Trust',
      copyright: '© 2026 Pramila Veerappa Educational Trust ® · All rights reserved',
      builtWith: 'Built with ❤ to support rural education',
    },
  },
  kn: {
    nav: {
      home: 'ಮುಖಪುಟ',
      about: 'ನಮ್ಮ ಬಗ್ಗೆ',
      campus: 'ಕ್ಯಾಂಪಸ್',
      activities: 'ಚಟುವಟಿಕೆಗಳು',
      donors: 'ದಾನಿಗಳು',
      contact: 'ಸಂಪರ್ಕಿಸಿ',
      donateNow: 'ಈಗ ದಾನ ಮಾಡಿ',
      langToggle: 'English',
    },
    hero: {
      title: 'ಪ್ರತಿ ಮಗಿವಿಗೆ ಉಚಿತ ಶಿಕ್ಷಣ',
      subtitle: 'ಪ್ರಮೀಳಾ ವೀರಪ್ಪ ಶೈಕ್ಷಣಿಕ ಟ್ರಸ್ಟ್ · ಸ್ಥಾಪನೆ 1985 · ವಳಗೆರೆಹಳ್ಳಿ, ಮದ್ದೂರು, ಕರ್ನಾಟಕ',
      donate: 'ಈಗ ದಾನ ಮಾಡಿ',
      story: 'ನಮ್ಮ ಕಥೆ →',
    },
    stats: {
      totalStudents: 'ಒಟ್ಟು ವಿದ್ಯಾರ್ಥಿಗಳು',
      teachers: 'ಶಿಕ್ಷಕರು',
      estYear: 'ಸ್ಥಾಪನೆ ವರ್ಷ',
      campusArea: 'ಕ್ಯಾಂಪಸ್ ಪ್ರದೇಶ',
      taxBenefit: 'ತೆರಿಗೆ ಪ್ರಯೋಜನ',
    },
    about: {
      label: 'ನಮ್ಮ ಕಥೆ',
      title: 'ಹಳ್ಳಿಯಲ್ಲಿ ಹುಟ್ಟಿದ ಕನಸು',
      p1: 'ವಿ.ಕೆ. ವೀರಪ್ಪ (1929–2017) ವಳಗೆರೆಹಳ್ಳಿ ಎಂಬ ಸಣ್ಣ ಹಳ್ಳಿಯ ಬಡ ಕುಟುಂಬದಲ್ಲಿ ಹುಟ್ಟಿದರು. ಅವರು ಕಷ್ಟಪಟ್ಟು ಓದಿ ಎಂಜಿನಿಯರ್ ಆದರು, ಆದರೆ ತಮ್ಮ ಬೇರುಗಳನ್ನು ಎಂದೂ ಮರೆಯಲಿಲ್ಲ.',
      p2: '1985 ರಲ್ಲಿ, ಅವರು ಕೆಲವು ಮಕ್ಕಳೊಂದಿಗೆ ಸಣ್ಣ ಶೆಡ್‌ನಲ್ಲಿ ಶಾಲೆಯನ್ನು ಪ್ರಾರಂಭಿಸಿದರು. ಅಚಲ ನಿರ್ಧಾರದಿಂದ, ಅವರು ದಾನ ನಿಧಿಯನ್ನು ಸಂಗ್ರಹಿಸಿ ಎರಡು ದಶಕಗಳಲ್ಲಿ ಇಡೀ ಕ್ಯಾಂಪಸ್ ನಿರ್ಮಿಸಿದರು.',
      p3: 'ಇಂದು, 200 ಕ್ಕೂ ಹೆಚ್ಚು ವಿದ್ಯಾರ್ಥಿಗಳು ಇಲ್ಲಿ ಓದುತ್ತಿದ್ದಾರೆ ಮತ್ತು ಎಂಜಿನಿಯರ್‌ಗಳು, ವೈದ್ಯರು ಮತ್ತು ವ್ಯಾಪಾರಿಗಳಾಗಿದ್ದಾರೆ — ಅವರ ಕನಸನ್ನು ನನಸು ಮಾಡಿದ್ದಾರೆ.',
      quote: '"ಪ್ರತಿ ದೇಶದ ಪ್ರಗತಿಯು ಮುಖ್ಯವಾಗಿ ಅದರ ಜನರ ಶಿಕ್ಷಣವನ್ನು ಅವಲಂಬಿಸಿರುತ್ತದೆ." — ಸರ್ ಎಂ. ವಿಶ್ವೇಶ್ವರಯ್ಯ',
    },
    campus: {
      label: 'ನಮ್ಮ ಕ್ಯಾಂಪಸ್',
      subtitle: '4 ಕಟ್ಟಡಗಳು · 5 ಎಕರೆ · ವಳಗೆರೆಹಳ್ಳಿ',
      mapCaption: 'ಕ್ಯಾಂಪಸ್ ವಿನ್ಯಾಸ — ವಳಗೆರೆಹಳ್ಳಿ, ಮದ್ದೂರು',
      boys: 'ಹುಡುಗರು',
      girls: 'ಹುಡುಗಿಯರು',
      teachersStat: 'ಶಿಕ್ಷಕರು',
      head: 'ಮುಖ್ಯಸ್ಥರು',
    },
    activities: {
      label: 'ಚಟುವಟಿಕೆಗಳು ಮತ್ತು ಕಾರ್ಯಕ್ರಮಗಳು',
      subtitle: 'ವಿದ್ಯಾರ್ಥಿ ಜೀವನದ ಒಂದು ನೋಟ',
      all: 'ಎಲ್ಲಾ',
      cultural: 'ಸಾಂಸ್ಕೃತಿಕ',
      academic: 'ಶೈಕ್ಷಣಿಕ',
      sports: 'ಕ್ರೀಡೆ',
      infrastructure: 'ಮೂಲಸೌಕರ್ಯ',
      viewPhotos: 'ಫೋಟೋಗಳನ್ನು ನೋಡಿ →',
    },
    donors: {
      label: 'ನಮ್ಮ ದಾನಿಗಳು',
      subtitle: 'ಈ ಕನಸನ್ನು ನಂಬಿದವರಿಗೆ ನಾವು ಕೃತಜ್ಞರು',
      manyDonors: '...ಮತ್ತು ಅನೇಕ ವೈಯಕ್ತಿಕ ದಾನಿಗಳು. ಧನ್ಯವಾದಗಳು.',
    },
    contact: {
      label: 'ನಮ್ಮನ್ನು ಬೆಂಬಲಿಸಿ',
      quote: '"ನೀರಿನ ಸಣ್ಣ ಹನಿಗಳು ಬೃಹತ್ ಸಾಗರವನ್ನು ಮಾಡುತ್ತವೆ."',
      subtitle: 'ಪ್ರತಿಯೊಂದು ಸಣ್ಣ ಕೊಡುಗೆ ಮುಖ್ಯ. ನಮ್ಮ ಶಾಲೆಯ ಮೂಲಸೌಕರ್ಯ ಮತ್ತು ಶಿಕ್ಷಣವನ್ನು ಸುಧಾರಿಸಲು ಸಹಾಯ ಮಾಡಿ.',
      getInTouch: 'ಸಂಪರ್ಕಿಸಿ',
      visitUs: 'ನಮ್ಮನ್ನು ಭೇಟಿ ಮಾಡಿ',
      directions: 'ಬೆಂಗಳೂರಿನಿಂದ NH 275 ಮೂಲಕ 90 ಕಿ.ಮೀ',
      supportMission: 'ನಮ್ಮ ಮಿಷನ್ ಅನ್ನು ಬೆಂಬಲಿಸಿ',
      registered: '12A ಮತ್ತು 80G ಅಡಿಯಲ್ಲಿ ನೋಂದಾಯಿಸಲಾಗಿದೆ',
      donateNow: 'ಈಗ ದಾನ ಮಾಡಿ',
    },
    footer: {
      trustName: 'ಪ್ರಮೀಳಾ ವೀರಪ್ಪ ಶೈಕ್ಷಣಿಕ ಟ್ರಸ್ಟ್',
      copyright: '© 2026 ಪ್ರಮೀಳಾ ವೀರಪ್ಪ ಶೈಕ್ಷಣಿಕ ಟ್ರಸ್ಟ್ ® · ಎಲ್ಲಾ ಹಕ್ಕುಗಳನ್ನು ಕಾಯ್ದಿರಿಸಲಾಗಿದೆ',
      builtWith: 'ಗ್ರಾಮೀಣ ಶಿಕ್ಷಣವನ್ನು ಬೆಂಬಲಿಸಲು ❤ ಯಿಂದ ನಿರ್ಮಿಸಲಾಗಿದೆ',
    },
  },
};

type Translations = typeof translations.en;

interface LanguageContextType {
  lang: Lang;
  toggleLang: () => void;
  t: Translations;
}

const LanguageContext = createContext<LanguageContextType>({
  lang: 'en',
  toggleLang: () => {},
  t: translations.en,
});

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [lang, setLang] = useState<Lang>('en');

  const toggleLang = () => setLang(prev => (prev === 'en' ? 'kn' : 'en'));

  return (
    <LanguageContext.Provider value={{ lang, toggleLang, t: translations[lang] }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  return useContext(LanguageContext);
}
