import { useQuery } from '@tanstack/react-query';
import api from '@/lib/api';
import { mockCampuses, type Campus } from '@/lib/mockData';

export function useCampuses() {
  return useQuery<Campus[]>({
    queryKey: ['campuses'],
    queryFn: async () => {
      try {
        const { data } = await api.get('/api/public/campuses');
        return data.data ?? data;
      } catch {
        return mockCampuses;
      }
    },
  });
}
