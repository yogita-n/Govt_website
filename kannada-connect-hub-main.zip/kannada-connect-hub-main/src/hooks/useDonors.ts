import { useQuery } from '@tanstack/react-query';
import api from '@/lib/api';
import { mockDonors, type Donor } from '@/lib/mockData';

export function useDonors() {
  return useQuery<Donor[]>({
    queryKey: ['donors'],
    queryFn: async () => {
      try {
        const { data } = await api.get('/api/public/donors');
        return data.data ?? data;
      } catch {
        return mockDonors;
      }
    },
  });
}
