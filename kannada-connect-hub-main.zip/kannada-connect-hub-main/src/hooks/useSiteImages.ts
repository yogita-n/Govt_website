import { useQuery } from '@tanstack/react-query';
import api from '@/lib/api';
import { mockSiteImages, type SiteImage } from '@/lib/mockData';

export function useSiteImages(isAdmin = false) {
  const base = isAdmin ? '/api/admin/site-images' : '/api/public/site-images';
  return useQuery<SiteImage[]>({
    queryKey: ['site-images', isAdmin],
    queryFn: async () => {
      try {
        const { data } = await api.get(base);
        return data.data ?? data;
      } catch {
        return mockSiteImages;
      }
    },
  });
}
