import { useQuery } from '@tanstack/react-query';
import api from '@/lib/api';
import { mockActivities, type Activity } from '@/lib/mockData';

export function useActivities() {
  return useQuery<Activity[]>({
    queryKey: ['activities'],
    queryFn: async () => {
      try {
        const { data } = await api.get('/api/public/activities');
        return data.data ?? data;
      } catch {
        return mockActivities;
      }
    },
  });
}
