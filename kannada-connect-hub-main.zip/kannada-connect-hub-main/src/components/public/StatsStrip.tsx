import { useLanguage } from '@/contexts/LanguageContext';

const statsData = [
  { value: '201', key: 'totalStudents' as const },
  { value: '18', key: 'teachers' as const },
  { value: '1985', key: 'estYear' as const },
  { value: '5 Acres', key: 'campusArea' as const },
  { value: '80G', key: 'taxBenefit' as const },
];

export default function StatsStrip() {
  const { t } = useLanguage();

  return (
    <section className="bg-background py-6 border-b border-lightgreen/30">
      <div className="max-w-6xl mx-auto px-4 flex overflow-x-auto gap-0">
        {statsData.map((s, i) => (
          <div key={s.key} className="flex items-center flex-shrink-0">
            <div className="text-center px-6 sm:px-10 py-2">
              <div className="font-heading text-2xl sm:text-3xl font-bold text-primary">{s.value}</div>
              <div className="text-xs sm:text-sm text-muted-foreground mt-1">{t.stats[s.key]}</div>
            </div>
            {i < statsData.length - 1 && <div className="hidden sm:block w-px h-10 bg-lightgreen/50 flex-shrink-0" />}
          </div>
        ))}
      </div>
    </section>
  );
}
