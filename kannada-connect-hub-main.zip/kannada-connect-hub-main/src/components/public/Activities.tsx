import { useState } from 'react';
import SectionLabel from '@/components/shared/SectionLabel';
import SkeletonCard from '@/components/shared/SkeletonCard';
import { useActivities } from '@/hooks/useActivities';
import { useLanguage } from '@/contexts/LanguageContext';
import { X, ChevronLeft, ChevronRight } from 'lucide-react';

export default function Activities() {
  const { data: activities, isLoading } = useActivities();
  const [filter, setFilter] = useState('All');
  const [lightbox, setLightbox] = useState<{ images: { url: string; caption: string }[]; index: number } | null>(null);
  const { t } = useLanguage();

  const categories = [
    { key: 'All', label: t.activities.all },
    { key: 'Cultural', label: t.activities.cultural },
    { key: 'Academic', label: t.activities.academic },
    { key: 'Sports', label: t.activities.sports },
    { key: 'Infrastructure', label: t.activities.infrastructure },
  ];

  const filtered = filter === 'All' ? activities : activities?.filter(a => a.category === filter);

  return (
    <section id="activities" className="bg-lightgreen/10 py-16 sm:py-24">
      <div className="max-w-6xl mx-auto px-4">
        <SectionLabel label={t.activities.label} />
        <p className="text-muted-foreground mb-6">{t.activities.subtitle}</p>

        <div className="flex flex-wrap gap-2 mb-8">
          {categories.map(c => (
            <button
              key={c.key}
              onClick={() => setFilter(c.key)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${filter === c.key ? 'bg-primary text-primary-foreground' : 'bg-card text-foreground hover:bg-lightgreen/50'}`}
            >
              {c.label}
            </button>
          ))}
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {isLoading
            ? Array.from({ length: 6 }).map((_, i) => <SkeletonCard key={i} />)
            : filtered?.map(a => (
                <div key={a.id} className="bg-card rounded-2xl shadow-md overflow-hidden border border-lightgreen/20">
                  <div className="relative">
                    {a.images[0] && (
                      <img src={a.images[0].url} alt={a.title} className="aspect-video w-full object-cover" />
                    )}
                    <span className="absolute top-3 left-3 bg-primary/90 text-primary-foreground text-xs px-2.5 py-1 rounded-full">
                      {a.category}
                    </span>
                  </div>
                  <div className="p-5 space-y-2">
                    <h3 className="font-heading text-lg font-bold text-foreground">{a.title}</h3>
                    <p className="text-xs text-muted-foreground">
                      {new Date(a.date).toLocaleDateString('en-IN', { year: 'numeric', month: 'long', day: 'numeric' })}
                    </p>
                    <p className="text-sm text-muted-foreground leading-relaxed">{a.description}</p>
                    {a.images.length > 0 && (
                      <button
                        onClick={() => setLightbox({ images: a.images, index: 0 })}
                        className="text-sm font-semibold text-accent hover:underline"
                      >
                        {t.activities.viewPhotos}
                      </button>
                    )}
                  </div>
                </div>
              ))}
        </div>
      </div>

      {/* Lightbox */}
      {lightbox && (
        <div className="fixed inset-0 z-[70] bg-foreground/90 flex items-center justify-center" onClick={() => setLightbox(null)}>
          <button className="absolute top-4 right-4 text-primary-foreground" onClick={() => setLightbox(null)}>
            <X className="w-8 h-8" />
          </button>
          <button className="absolute left-4 text-primary-foreground" onClick={(e) => { e.stopPropagation(); setLightbox(l => l ? { ...l, index: Math.max(0, l.index - 1) } : null); }}>
            <ChevronLeft className="w-10 h-10" />
          </button>
          <button className="absolute right-4 text-primary-foreground" onClick={(e) => { e.stopPropagation(); setLightbox(l => l ? { ...l, index: Math.min(l.images.length - 1, l.index + 1) } : null); }}>
            <ChevronRight className="w-10 h-10" />
          </button>
          <div className="max-w-4xl max-h-[80vh] px-4" onClick={e => e.stopPropagation()}>
            <img src={lightbox.images[lightbox.index].url} alt="" className="max-h-[70vh] mx-auto rounded-lg object-contain" />
            {lightbox.images[lightbox.index].caption && (
              <p className="text-primary-foreground text-center mt-3">{lightbox.images[lightbox.index].caption}</p>
            )}
            <p className="text-primary-foreground/60 text-center text-sm mt-1">{lightbox.index + 1} / {lightbox.images.length}</p>
          </div>
        </div>
      )}
    </section>
  );
}
