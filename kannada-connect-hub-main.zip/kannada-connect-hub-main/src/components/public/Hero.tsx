import { useSiteImages } from '@/hooks/useSiteImages';
import { useLanguage } from '@/contexts/LanguageContext';

export default function Hero() {
  const { data: images } = useSiteImages();
  const heroUrl = images?.find(i => i.key === 'hero_banner')?.url || '';
  const { t } = useLanguage();

  const scrollTo = (href: string) => {
    document.querySelector(href)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="home" className="relative min-h-[600px] flex items-center justify-center overflow-hidden">
      {heroUrl && (
        <img src={heroUrl} alt="Hero banner" className="absolute inset-0 w-full h-full object-cover" />
      )}
      <div className="absolute inset-0 bg-darkgreen/70" />
      <div className="relative z-10 text-center px-4 py-20 max-w-4xl mx-auto">
        <h1 className="font-heading text-4xl sm:text-5xl md:text-6xl font-bold text-primary-foreground mb-4 leading-tight">
          {t.hero.title}
        </h1>
        <p className="text-primary-foreground/80 text-lg sm:text-xl mb-8 max-w-2xl mx-auto">
          {t.hero.subtitle}
        </p>
        <div className="flex flex-wrap justify-center gap-4">
          <button onClick={() => scrollTo('#contact')} className="bg-accent text-accent-foreground px-8 py-3.5 rounded-xl text-lg font-semibold hover:bg-accent/90 transition-colors">
            {t.hero.donate}
          </button>
          <button onClick={() => scrollTo('#about')} className="border-2 border-primary-foreground text-primary-foreground px-8 py-3.5 rounded-xl text-lg font-semibold hover:bg-primary-foreground/10 transition-colors">
            {t.hero.story}
          </button>
        </div>
      </div>
    </section>
  );
}
