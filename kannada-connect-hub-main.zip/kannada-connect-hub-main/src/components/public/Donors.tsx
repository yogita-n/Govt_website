import SectionLabel from '@/components/shared/SectionLabel';
import { useDonors } from '@/hooks/useDonors';
import { useContactInfo } from '@/hooks/useContactInfo';
import { useLanguage } from '@/contexts/LanguageContext';

export default function Donors() {
  const { data: donors } = useDonors();
  const { data: contact } = useContactInfo();
  const { t } = useLanguage();

  return (
    <section id="donors" className="bg-background py-16 sm:py-24">
      <div className="max-w-4xl mx-auto px-4 text-center">
        <SectionLabel label={t.donors.label} />
        <p className="text-muted-foreground mb-8">{t.donors.subtitle}</p>

        <div className="flex flex-wrap justify-center gap-3 mb-6">
          {donors?.map(d => (
            <span key={d.id} className="bg-lightgreen/30 text-foreground px-4 py-2 rounded-full text-sm">
              {d.name}
              {d.location && <span className="text-muted-foreground"> · {d.location}</span>}
            </span>
          ))}
        </div>

        <p className="text-muted-foreground italic mb-6">{t.donors.manyDonors}</p>

        {contact?.taxNote && (
          <div className="bg-lightgreen/20 rounded-xl p-5 max-w-2xl mx-auto">
            <p className="text-sm text-muted-foreground">{contact.taxNote}</p>
          </div>
        )}
      </div>
    </section>
  );
}
