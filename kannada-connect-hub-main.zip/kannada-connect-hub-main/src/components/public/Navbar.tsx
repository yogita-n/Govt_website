import { useState, useEffect } from 'react';
import { Menu, X, Globe } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const { t, toggleLang } = useLanguage();

  const navLinks = [
    { label: t.nav.home, href: '#home' },
    { label: t.nav.about, href: '#about' },
    { label: t.nav.campus, href: '#campus' },
    { label: t.nav.activities, href: '#activities' },
    { label: t.nav.donors, href: '#donors' },
    { label: t.nav.contact, href: '#contact' },
  ];

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 80);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const scrollTo = (href: string) => {
    setMobileOpen(false);
    const el = document.querySelector(href);
    el?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <>
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'bg-darkgreen/95 backdrop-blur shadow-lg' : 'bg-darkgreen'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between h-16">
          <button onClick={() => scrollTo('#home')} className="font-heading text-xl font-bold text-primary-foreground tracking-wide">
            PVET
          </button>
          <div className="hidden md:flex items-center gap-6">
            {navLinks.map(l => (
              <button key={l.href} onClick={() => scrollTo(l.href)} className="text-sm text-primary-foreground/80 hover:text-primary-foreground transition-colors">
                {l.label}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-3">
            {/* Language Toggle Button */}
            <button
              onClick={toggleLang}
              className="flex items-center gap-1.5 bg-primary-foreground/10 hover:bg-primary-foreground/20 text-primary-foreground px-3 py-1.5 rounded-lg text-sm font-medium transition-colors border border-primary-foreground/20"
              title="Switch Language"
            >
              <Globe className="w-4 h-4" />
              <span>{t.nav.langToggle}</span>
            </button>
            <button onClick={() => scrollTo('#contact')} className="hidden sm:block bg-accent text-accent-foreground px-5 py-2 rounded-lg text-sm font-semibold hover:bg-accent/90 transition-colors">
              {t.nav.donateNow}
            </button>
            <button onClick={() => setMobileOpen(true)} className="md:hidden text-primary-foreground p-2">
              <Menu className="w-6 h-6" />
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-[60] bg-darkgreen flex flex-col">
          <div className="flex items-center justify-between px-4 h-16">
            <span className="font-heading text-xl font-bold text-primary-foreground">PVET</span>
            <button onClick={() => setMobileOpen(false)} className="text-primary-foreground p-2"><X className="w-6 h-6" /></button>
          </div>
          <div className="flex-1 flex flex-col items-center justify-center gap-6">
            {navLinks.map(l => (
              <button key={l.href} onClick={() => scrollTo(l.href)} className="text-2xl text-primary-foreground font-heading hover:text-lightgreen transition-colors">
                {l.label}
              </button>
            ))}
            <button
              onClick={toggleLang}
              className="flex items-center gap-2 text-primary-foreground text-lg font-medium hover:text-lightgreen transition-colors"
            >
              <Globe className="w-5 h-5" />
              {t.nav.langToggle}
            </button>
            <button onClick={() => scrollTo('#contact')} className="mt-4 bg-accent text-accent-foreground px-8 py-3 rounded-xl text-lg font-semibold">
              {t.nav.donateNow}
            </button>
          </div>
        </div>
      )}
    </>
  );
}
