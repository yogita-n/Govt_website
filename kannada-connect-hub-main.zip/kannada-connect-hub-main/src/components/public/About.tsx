import SectionLabel from '@/components/shared/SectionLabel';
import { useSiteImages } from '@/hooks/useSiteImages';
import { useLanguage } from '@/contexts/LanguageContext';

export default function About() {
  const { data: images } = useSiteImages();
  const founderUrl = images?.find(i => i.key === 'founder_portrait')?.url || '';
  const { t } = useLanguage();

  return (
    <section id="about" className="bg-lightgreen/20 py-16 sm:py-24">
      <div className="max-w-6xl mx-auto px-4">
        <SectionLabel label={t.about.label} />
        <div className="grid md:grid-cols-2 gap-10 items-start mt-6">
          <div className="relative">
            {founderUrl && (
              <img src={founderUrl} alt="Founder V.K. Veerappa" className="w-full rounded-2xl shadow-lg object-cover aspect-[3/4]" />
            )}
          </div>
          <div className="space-y-5">
            <h2 className="font-heading text-3xl sm:text-4xl font-bold text-foreground">{t.about.title}</h2>
            <p className="text-muted-foreground leading-relaxed">{t.about.p1}</p>
            <p className="text-muted-foreground leading-relaxed">{t.about.p2}</p>
            <p className="text-muted-foreground leading-relaxed">{t.about.p3}</p>
            <blockquote className="border-l-4 border-primary pl-4 italic text-muted-foreground">
              {t.about.quote}
            </blockquote>
          </div>
        </div>
      </div>
    </section>
  );
}
