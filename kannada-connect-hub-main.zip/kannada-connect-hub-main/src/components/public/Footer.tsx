import { useLanguage } from '@/contexts/LanguageContext';

export default function Footer() {
  const { t } = useLanguage();

  const navLinks = [
    { label: t.nav.home, id: 'home' },
    { label: t.nav.about, id: 'about' },
    { label: t.nav.campus, id: 'campus' },
    { label: t.nav.activities, id: 'activities' },
    { label: t.nav.donors, id: 'donors' },
    { label: t.nav.contact, id: 'contact' },
  ];

  return (
    <footer className="bg-foreground py-10">
      <div className="max-w-6xl mx-auto px-4 text-center space-y-5">
        <div>
          <span className="font-heading text-xl font-bold text-background">PVET</span>
          <p className="text-background/50 text-sm mt-1">{t.footer.trustName}</p>
        </div>
        <div className="flex flex-wrap justify-center gap-4">
          {navLinks.map(l => (
            <button
              key={l.id}
              onClick={() => document.querySelector(`#${l.id}`)?.scrollIntoView({ behavior: 'smooth' })}
              className="text-sm text-background/60 hover:text-background transition-colors"
            >
              {l.label}
            </button>
          ))}
        </div>
        <div className="border-t border-background/10 pt-5 space-y-2">
          <p className="text-background/40 text-xs">{t.footer.copyright}</p>
          <p className="text-background/30 text-xs">{t.footer.builtWith}</p>
        </div>
      </div>
    </footer>
  );
}
