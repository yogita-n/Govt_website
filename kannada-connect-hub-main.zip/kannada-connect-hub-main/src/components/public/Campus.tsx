import SectionLabel from '@/components/shared/SectionLabel';
import SkeletonCard from '@/components/shared/SkeletonCard';
import { useCampuses } from '@/hooks/useCampuses';
import { useSiteImages } from '@/hooks/useSiteImages';
import { useLanguage } from '@/contexts/LanguageContext';

export default function Campus() {
  const { data: campuses, isLoading } = useCampuses();
  const { data: images } = useSiteImages();
  const campusMapUrl = images?.find(i => i.key === 'campus_map')?.url || '';
  const { t } = useLanguage();

  return (
    <section id="campus" className="bg-background py-16 sm:py-24">
      <div className="max-w-6xl mx-auto px-4">
        <SectionLabel label={t.campus.label} />
        <p className="text-muted-foreground mb-8">{t.campus.subtitle}</p>

        {campusMapUrl && (
          <div className="mb-10 rounded-2xl overflow-hidden shadow-md">
            <img src={campusMapUrl} alt={t.campus.mapCaption} className="w-full object-cover" />
            <p className="text-xs text-muted-foreground text-center py-2 bg-muted">{t.campus.mapCaption}</p>
          </div>
        )}

        <div className="grid sm:grid-cols-2 gap-6">
          {isLoading
            ? Array.from({ length: 4 }).map((_, i) => <SkeletonCard key={i} />)
            : campuses?.map(c => (
                <div key={c.slug} className="bg-card rounded-2xl shadow-md overflow-hidden border border-lightgreen/20">
                  <img src={c.image.url} alt={c.title} className="aspect-video w-full object-cover" />
                  <div className="p-5 space-y-3">
                    <h3 className="font-heading text-lg font-bold text-foreground">{c.title}</h3>
                    <p className="text-sm text-muted-foreground">{c.subtitle}</p>
                    <p className="text-foreground text-sm leading-relaxed">{c.description}</p>
                    {c.hasStats && c.stats && (
                      <div className="grid grid-cols-2 gap-2 mt-3">
                        {[
                          { label: t.campus.boys, val: c.stats.boys },
                          { label: t.campus.girls, val: c.stats.girls },
                          { label: t.campus.teachersStat, val: c.stats.teachers },
                          { label: t.campus.head, val: c.stats.head },
                        ].map(s => (
                          <div key={s.label} className="bg-lightgreen/30 rounded-lg p-2.5 text-center">
                            <div className="font-heading font-bold text-primary text-sm">{s.val}</div>
                            <div className="text-xs text-muted-foreground">{s.label}</div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ))}
        </div>
      </div>
    </section>
  );
}
