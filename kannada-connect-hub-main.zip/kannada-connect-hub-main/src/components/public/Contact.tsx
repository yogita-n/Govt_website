import { Mail, MapPin, Heart } from 'lucide-react';
import { useContactInfo } from '@/hooks/useContactInfo';
import { useLanguage } from '@/contexts/LanguageContext';

export default function Contact() {
  const { data: contact } = useContactInfo();
  const { t } = useLanguage();

  return (
    <section id="contact" className="bg-lightgreen/10 py-16 sm:py-24">
      <div className="max-w-6xl mx-auto px-4">
        <h2 className="font-heading text-2xl sm:text-3xl font-bold text-foreground text-center mb-2">
          {t.contact.quote}
        </h2>
        <p className="text-muted-foreground text-center mb-10 max-w-2xl mx-auto">
          {t.contact.subtitle}
        </p>

        <div className="grid md:grid-cols-3 gap-6">
          <div className="bg-card rounded-2xl shadow-md p-6 space-y-3">
            <Mail className="w-8 h-8 text-primary" />
            <h3 className="font-heading text-lg font-bold text-foreground">{t.contact.getInTouch}</h3>
            {contact && (
              <div className="space-y-1 text-sm text-muted-foreground">
                <p className="font-semibold text-foreground">{contact.contactPersonName}</p>
                <p>{contact.contactPersonTitle}</p>
                <p>{contact.email}</p>
                <p>{contact.phone}</p>
              </div>
            )}
          </div>

          <div className="bg-card rounded-2xl shadow-md p-6 space-y-3">
            <MapPin className="w-8 h-8 text-primary" />
            <h3 className="font-heading text-lg font-bold text-foreground">{t.contact.visitUs}</h3>
            {contact && (
              <div className="space-y-1 text-sm text-muted-foreground">
                <p>{contact.address}</p>
                <p className="font-medium">{t.contact.directions}</p>
              </div>
            )}
          </div>

          <div className="bg-card rounded-2xl shadow-md p-6 space-y-3">
            <Heart className="w-8 h-8 text-accent" />
            <h3 className="font-heading text-lg font-bold text-foreground">{t.contact.supportMission}</h3>
            <p className="text-sm text-muted-foreground">{t.contact.registered}</p>
            {contact && <p className="text-xs text-muted-foreground">{contact.taxNote}</p>}
            <button
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              className="mt-3 w-full bg-accent text-accent-foreground py-3 rounded-xl font-semibold hover:bg-accent/90 transition-colors"
            >
              {t.contact.donateNow}
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
